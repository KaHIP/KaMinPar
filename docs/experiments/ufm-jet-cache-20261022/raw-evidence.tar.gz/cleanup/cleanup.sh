#!/usr/bin/env bash
#SBATCH --job-name=ufm-cache-cleanup
#SBATCH --partition=dijkstra
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=64
#SBATCH --exclusive
#SBATCH --mem=0
#SBATCH --time=00:05:00
set -euo pipefail
[[ -n ${SLURM_JOB_ID:-} && $(hostname -s) == dijkstra ]] || exit 2
python3 - <<'PY'
from pathlib import Path
import hashlib,json,datetime,os
root=Path('/nfs/work/seemaier/experiments/ufm-jet-cache-20261022')
plan=json.loads((root/'results/plan.json').read_text())
stage=Path('/dev/shm/seemaier-ufm-jet-cache-20261022')
assert plan['config']['stage_dir']==str(stage) and stage.resolve()==stage and not stage.is_symlink()
expected={Path(g['path']).name:g for g in plan['inputs']}
assert len(expected)==6
assert {p.name for p in stage.iterdir()}==set(expected), 'Unexpected files in owned staging directory'
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()
records=[]
for name,g in expected.items():
    path=stage/name
    assert Path(g['path'])==path and path.is_file() and not path.is_symlink()
    assert path.stat().st_size==g['bytes'] and digest(path)==g['sha256']
    assert digest(Path(g['source']))==g['sha256'], 'Original input changed'
    records.append(dict(path=str(path),bytes=g['bytes'],sha256=g['sha256'],original_source=g['source'],original_hash_unchanged=True))
for name in expected:(stage/name).unlink()
stage.rmdir()
record=dict(job_id=os.environ['SLURM_JOB_ID'],removed_staging_directory=str(stage),removed_files=records,removed_bytes=sum(x['bytes'] for x in records),stage_directory_absent=not stage.exists(),completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(root/'cleanup').mkdir(exist_ok=True)
(root/'cleanup/manifest.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps(record,indent=2))
PY
