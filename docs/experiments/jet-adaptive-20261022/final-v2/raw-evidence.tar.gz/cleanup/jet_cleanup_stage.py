#!/usr/bin/env python3
"""Remove only this completed experiment's hash-verified staged graph copies."""
from pathlib import Path
import hashlib
import json
import os
import socket
from datetime import datetime, timezone

root = Path('/nfs/work/seemaier/experiments/jet-adaptive-20261022')
stage = Path('/dev/shm/seemaier-jet-adaptive-20261022')
assert socket.gethostname().split('.')[0] == 'dijkstra'
plan = json.loads((root / 'results/plan.json').read_text())
summary = json.loads((root / 'results/summary.json').read_text())
assert summary['complete'] and summary['completed'] == summary['planned'] == 180
assert len(plan['inputs']) == 6 and len(plan['jobs']) == 180
assert stage.is_dir() and not stage.is_symlink() and stage.stat().st_uid == os.getuid()
expected = {Path(entry['path']) for entry in plan['inputs']}
assert all(path.parent == stage for path in expected)
assert set(stage.iterdir()) == expected, 'Unexpected staged files: preserve directory'
records = []
for entry in plan['inputs']:
    path = Path(entry['path'])
    assert path.is_file() and not path.is_symlink()
    assert path.stat().st_uid == os.getuid() and path.stat().st_size == entry['bytes']
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            digest.update(chunk)
    assert digest.hexdigest() == entry['sha256'], f'Changed staged input: {path}'
    records.append(dict(path=str(path), bytes=entry['bytes'], sha256=digest.hexdigest()))
# Validate all six before deleting any; original corpus files are never modified.
for path in expected:
    path.unlink()
stage.rmdir()
result = dict(host=socket.gethostname(), job_id=os.environ.get('SLURM_JOB_ID'),
              completed_utc=datetime.now(timezone.utc).isoformat(),
              removed=records, removed_bytes=sum(r['bytes'] for r in records),
              stage_directory_removed=not stage.exists(),
              source_corpus_modified=False)
(root / 'stage-cleanup.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, indent=2, sort_keys=True))
