# Reduced UFM Jet experiment

Completed 30/180; statuses: {'ok': 29, 'interrupted_for_candidate_revision': 1}.

All ratios below are candidate/reference; smaller is better. Runtime is total partitioning time, excluding input/output; RSS is process-wide peak resident memory.

| Comparison | Matched runs | Runtime ratio | Cut ratio | RSS ratio | Jet time ratio |
|---|---:|---:|---:|---:|---:|
| cache_with_overload | 5 | 0.8782 | 0.9927 | 1.0612 | 0.8142 |
| cache_with_jet | 6 | 0.6449 | 1.0676 | 0.9632 | 0.4791 |
| balancer_with_sparse | 5 | 0.6103 | 0.8739 | 1.0311 | 0.5574 |
| balancer_with_jet | 6 | 0.3153 | 0.9312 | 0.9269 | 0.2178 |
| combined_vs_original | 5 | 0.3232 | 0.9453 | 0.9910 | 0.2223 |
| combined_vs_ufm | 6 | 1.3626 | 1.0100 | 0.9707 | — |

The study uses six selected UFM corpus graphs, k=16/1024 and three seeds, with 32 physical cores on one exclusive allocation. The eco arm is the repository's unconstrained LP + UFM preset. Graph selection is fixed before measurements. This screening subset does not establish full-corpus superiority.

`plan.json` records every command, source/executable/input hashes and arm order. `runs.jsonl` retains failed, timed-out and infeasible runs; `summary.json` lists missing/invalid comparison pairs. Every successful run has an independently checked exact block-size output. All four Jet arms use the same binary. The legacy arm uses explicit sparse cache + overload balancer within the candidate source, not a separately compiled pre-change program. All Jet arms also share the best-partition feasibility safety correction. Per-level Jet timers are summed without double-counting descendants; phase totals are included in summary.json.
